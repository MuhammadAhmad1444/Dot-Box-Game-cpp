#include<iostream>
#include <string>
#include<ctime>
using namespace std;
int main()
{
	srand(time(NULL));                 //srand is used for random value of toss.
	int row = 0, col_1 = 0;           //Values of Rows And Column for Horizontal lines in Box
	int col = 0, row_1 = 0;          //Values of Rows And Columns for vertical  lines in Box
	int repeat;                     //Number of turns
	int Total_Score = 0;
	int box1 = 0, box2 = 0, box3 = 0, box4 = 0, box5 = 0, box6 = 0, box7 = 0, box8 = 0, box9 = 0;  //Box is used for checking the line in boxes.
	int check_r[4][3] = { { 0,0,0 },
	{ 0,0,0 },
	{ 0,0,0 },                         //Array for checking dublicate Horizontal Lines.
	{ 0,0,0 }
	};
	int check_c[3][4] = { { 0,0,0,0 },
	{ 0,0,0,0 },                        //Array for checking dublicate Vertical Lines.
	{ 0,0,0,0 }
	};

	int player_1_Score = 0, player_2_Score = 0;
	string player_1_name, player_2_name;
	string player_1_symbol, player_2_symbol;
	string arr1[4][4] =
	{
		{ "\t\t\t\t\to","o","o","o" },
		{ "\t\t\t\t\to","o","o","o" },     //Array which represents Dots.
		{ "\t\t\t\t\to","o","o","o" },
		{ "\t\t\t\t\to","o","o","o" }
	};
	//| line array
	string arr2[3][4] = { { "\t\t\t\t\t "," "," "," " },
	{ "\t\t\t\t\t "," "," "," " },          //Array which represents Vertical Lines.
	{ "\t\t\t\t\t "," "," "," " }
	};

	string arr3[3][4] = { { "       ","       ","       " },
	{ "       ","       ","       " },        //Array which represents the Symbol of Player in Box.
	{ "       ","       ","       " },
	};

	string spec_value = "0";
	cout << "Enter Player One Name=";
	getline(cin, player_1_name);
	cout << "Enter Player One lucky Alphabet =";
	getline(cin, player_1_symbol);
	cout << "Enter Player Two Name=";
	getline(cin, player_2_name);
	cout << "Enter Player Two lucky Alphabet =";
	getline(cin, player_2_symbol);
	cout << player_1_name << " Score = " << player_1_Score << endl;
	cout << player_2_name << " Score = " << player_2_Score << endl;

	for (int row_out = 0; row_out < 4; row_out++)
	{
		for (int col_out = 0; col_out < 4; col_out++)
		{                                                       //Two Dimentional Array represents Grid of Board.

			cout << arr1[row_out][col_out] << "\t";

		}
		cout << endl << endl << endl;
	}
	cout << "Game is Starting NoW" << endl;
	//tossing
	cout << "BEFORE STARTING THE GAME LET'S HAVE A TOSS FIRST\n";
	cout << "To continue the toss press any key:";
	system("pause>0");
	int moves = 100;                                     //Number of Turns
	repeat = rand() % 2;                               //Random Number for Toss.
	if (repeat == 1)
	{
		moves += 1;
		cout << "\n                               -----------------------------------------\n";
		cout << "                              " << "\t\t" << player_2_name << " Wins the Toss\n";
		cout << "                               -----------------------------------------\n";
	}
	else
	{
		cout << "\n                               -----------------------------------------\n";
		cout << "                               " << "\t\t" << player_1_name << " Wins the Toss\n";
		cout << "                               -----------------------------------------\n";
	}


	while (repeat < moves)
	{
		Total_Score = player_1_Score + player_2_Score;
		if (repeat % 2 == 0)
		{
			cout << "Turn Of  " << player_1_name << "\n";
			cout << player_1_name << " Score = " << player_1_Score << endl;
		}
		else
		{

			cout << "Turn Of  " << player_2_name << "\n";
			cout << player_2_name << " Score = " << player_2_Score << endl;

		}


		cout << "For drawing the lines on the board, You have two choices of lines (horizontal/vertical)\n";
		cout << "Character 'r' represents horizontal lines and 'c' represents vertical lines\n";
		cout << "Enter your choice.'r'or 'c':";
		cin >> spec_value;
		if (spec_value == "r" || spec_value == "c")
		{
			//IF cnndition is used Checking the values Other than  'r' OR 'c'.

			if (spec_value == "r")
			{
				cout << "Enter the row number:";
				cin >> row;
				while (!cin)
				{
					cin.clear();
					cin.ignore(100, '\n');                 //Clear and ignores the bad input
					cout << "Invalid Input.Please Try again\n";
					cout << "Enter the row number:";
					cin >> row;
				}
				cout << "Enter the column number:";
				cin >> col_1;
				while (!cin)
				{
					cin.clear();                           //Clear and ignores the bad input
					cin.ignore(100, '\n');
					cout << "Invalid Input.Please Try again\n";
					cout << "Enter the column number:";
					cin >> col_1;
				}
				//If a certain value of row and columns meets the condition,
				//then it upgrades the value of lines in boxes 
				//and repetition of that certain value is ignored
				if (row == 0 && col_1 == 0)
				{
					check_r[0][0] += 1;

					if (!(check_r[0][0] >= 2))
					{
						box1 += 1;
					}
					if (check_r[0][0] >= 2)
					{
						repeat--;
						cout << "You cannot draw line on a same location\n";

					}

				}
				else if (row == 1 && col_1 == 0)
				{
					check_r[1][0] += 1;
					if (!(check_r[1][0] >= 2))
					{
						box1 += 1;
						box4 += 1;
					}
					if (check_r[1][0] >= 2)
					{
						repeat--;
						cout << "You cannot draw line on a same location\n";
					}
				}

				else if (row == 2 && col_1 == 0)
				{
					check_r[2][0] += 1;
					if (!(check_r[2][0] >= 2))
					{
						box4 += 1;
						box7 += 1;
					}
					if (check_r[2][0] >= 2)
					{
						repeat--;
						cout << "You cannot draw line on a same location\n";
					}
				}
				else if (row == 3 && col_1 == 0)
				{
					check_r[3][0] += 1;
					if (!(check_r[3][0] >= 2))
					{
						box7 += 1;
					}
					if (check_r[3][0] >= 2)
					{
						repeat--;
						cout << "You cannot draw line on a same location\n";
					}
				}
				else if (row == 0 && col_1 == 1)
				{
					check_r[0][1] += 1;
					if (!(check_r[0][1] >= 2))
					{
						box2 += 1;
					}
					if (check_r[0][1] >= 2)
					{
						repeat--;
						cout << "You cannot draw line on a same location\n";

					}
				}
				else if (row == 1 && col_1 == 1)
				{
					check_r[1][1] += 1;
					if (!(check_r[1][1] >= 2))
					{
						box2 += 1;
						box5 += 1;
					}
					if (check_r[1][1] >= 2)
					{
						repeat--;
						cout << "You cannot draw line on a same location\n";

					}
				}
				else if (row == 2 && col_1 == 1)
				{
					check_r[2][1] += 1;
					if (!(check_r[2][1] >= 2))
					{
						box5 += 1;
						box8 += 1;
					}
					if (check_r[2][1] >= 2)
					{
						repeat--;
						cout << "You cannot draw line on a same location\n";

					}
				}
				else if (row == 3 && col_1 == 1)
				{
					check_r[3][1] += 1;
					if (!(check_r[3][1] >= 2))
					{
						box8 += 1;
					}
					if (check_r[3][1] >= 2)
					{
						repeat--;
						cout << "You cannot draw line on a same location\n";

					}
				}
				else if (row == 0 && col_1 == 2)
				{
					check_r[0][2] += 1;
					if (!(check_r[0][2] >= 2))
					{
						box3 += 1;
					}
					if (check_r[0][2] >= 2)
					{
						repeat--;
						cout << "You cannot draw line on a same location\n";

					}
				}
				else if (row == 1 && col_1 == 2)
				{
					check_r[1][2] += 1;
					if (!(check_r[1][2] >= 2))
					{
						box3 += 1;
						box6 += 1;
					}
					if (check_r[1][2] >= 2)
					{
						repeat--;
						cout << "You cannot draw line on a same location\n";

					}
				}
				else if (row == 2 && col_1 == 2)
				{
					check_r[2][2] += 1;
					if (!(check_r[2][2] >= 2))
					{
						box6 += 1;
						box9 += 1;
					}
					if (check_r[2][2] >= 2)
					{
						repeat--;
						cout << "You cannot draw line on a same location\n";

					}
				}
				else if (row == 3 && col_1 == 2)
				{
					check_r[3][2] += 1;
					if (!(check_r[3][2] >= 2))
					{
						box9 += 1;
					}
					if (check_r[3][2] >= 2)
					{
						repeat--;
						cout << "You cannot draw line on a same location\n";

					}
				}

				if ((repeat % 2 == 0 || repeat % 2 == 1) && box1 == 4)
				{
					//Upgrading Score values  And  Assigns the Symbols in Boxs.
					if (repeat % 2 == 0)
					{
						arr3[0][0] = "   " + player_1_symbol + "   ";
						player_1_Score = player_1_Score + 1;
					}

					else if (repeat % 2 == 1)
					{
						arr3[0][0] = "   " + player_2_symbol + "   ";
						player_2_Score = player_2_Score + 1;
					}
				}
				if ((repeat % 2 == 0 || repeat % 2 == 1) && box2 == 4)
				{
					if (repeat % 2 == 0)
					{
						arr3[0][1] = "   " + player_1_symbol + "   ";
						player_1_Score = player_1_Score + 1;
					}
					else if (repeat % 2 == 1)
					{
						arr3[0][1] = "   " + player_2_symbol + "   ";
						player_2_Score = player_2_Score + 1;
					}
				}
				if ((repeat % 2 == 0 || repeat % 2 == 1) && box3 == 4)
				{
					if (repeat % 2 == 0)
					{
						{	arr3[0][2] = "   " + player_1_symbol + "   ";
						player_1_Score = player_1_Score + 1; }
					}
					else if (repeat % 2 == 1)
					{
						arr3[0][2] = "   " + player_2_symbol + "   ";
						player_2_Score = player_2_Score + 1;
					}
				}
				if ((repeat % 2 == 0 || repeat % 2 == 1) && box4 == 4)
				{
					if (repeat % 2 == 0)
					{
						arr3[1][0] = "   " + player_1_symbol + "   ";
						player_1_Score = player_1_Score + 1;
					}
					else if (repeat % 2 == 1)
					{
						arr3[1][0] = "   " + player_2_symbol + "   ";
						player_2_Score = player_2_Score + 1;
					}

				}
				if ((repeat % 2 == 0 || repeat % 2 == 1) && box5 == 4)
				{
					if (repeat % 2 == 0)
					{
						arr3[1][1] = "   " + player_1_symbol + "   ";
						player_1_Score = player_1_Score + 1;
					}
					else if (repeat % 2 == 1)
					{
						arr3[1][1] = "   " + player_2_symbol + "   ";
						player_2_Score = player_2_Score + 1;
					}
				}
				if ((repeat % 2 == 0 || repeat % 2 == 1) && box6 == 4)
				{
					if (repeat % 2 == 0)
					{
						arr3[1][2] = "   " + player_1_symbol + "   ";
						player_1_Score = player_1_Score + 1;
					}
					else if (repeat % 2 == 1)
					{
						arr3[1][2] = "   " + player_2_symbol + "   ";
						player_2_Score = player_2_Score + 1;
					}
				}
				if ((repeat % 2 == 0 || repeat % 2 == 1) && box7 == 4)
				{
					if (repeat % 2 == 0)
					{
						arr3[2][0] = "   " + player_1_symbol + "   ";
						player_1_Score = player_1_Score + 1;
					}
					else if (repeat % 2 == 1)
					{
						arr3[2][0] = "   " + player_2_symbol + "   ";
						player_2_Score = player_2_Score + 1;
					}
				}
				if ((repeat % 2 == 0 || repeat % 2 == 1) && box8 == 4)
				{
					if (repeat % 2 == 0)
					{
						arr3[2][1] = "   " + player_1_symbol + "   ";
						player_1_Score = player_1_Score + 1;
					}
					else if (repeat % 2 == 1)
					{
						arr3[2][1] = "   " + player_2_symbol + "   ";
						player_2_Score = player_2_Score + 1;
					}
				}
				if ((repeat % 2 == 0 || repeat % 2 == 1) && box9 == 4)
				{
					if (repeat % 2 == 0)
					{
						arr3[2][2] = "   " + player_1_symbol + "   ";
						player_1_Score = player_1_Score + 1;
					}
					else if (repeat % 2 == 1)
					{
						arr3[2][2] = "   " + player_2_symbol + "   ";
						player_2_Score = player_2_Score + 1;
					}
				}
				if (box1 == 4)         //Extra Turn After completing the Boxes.
				{
					repeat += 2;
					box1 = 0;

				}
				if (box2 == 4)
				{
					repeat += 2;
					box2 = 0;
				}
				if (box3 == 4)
				{
					repeat += 2;
					box3 = 0;
				}
				if (box4 == 4)
				{
					repeat += 2;
					box4 = 0;
				}
				if (box5 == 4)
				{
					repeat += 2;
					box5 = 0;
				}
				if (box6 == 4)
				{
					repeat += 2;
					box6 = 0;
				}
				if (box7 == 4)
				{
					repeat += 2;
					box7 = 0;
				}
				if (box8 == 4)
				{
					repeat += 2;
					box8 = 0;
				}
				if (box9 == 4)
				{
					repeat += 2;
					box9 = 0;
				}                                            //Control The out of range values.
				if (col_1 >= 3)
				{
					col_1 = 4;
					repeat--;
					cout << "Out of range. Please Try again\n";
					system("pause");
				}
				if (row > 3)
				{

					repeat--;
					cout << "Out of range. Please Try again\n";
					system("pause");
				}
				for (int row_out = 0; row_out < 4; row_out++)
				{                                                         //Horizontal Lines In Array
					for (int col_out = 0; col_out < 4; col_out++)
					{

						if (row == 0 && col_1 == 0 || row == 1 && col_1 == 0 || row == 2 && col_1 == 0 || row == 3 && col_1 == 0)
						{
							arr1[row][col_1] = "\t\t\t\t\to -----";
						}

						else if (col_out == col_1 && row_out == row)
						{

							arr1[row_out][col_out] = "o -----";
						}
					}

				}
			}
			else if (spec_value == "c")
			{
				cout << "Enter the column number:";
				cin >> col;
				while (!cin)
				{
					cin.clear();                             //Clear and ignores the bad input
					cin.ignore(100, '\n');
					cout << "Invalid Input.Please Try again\n";
					cout << "Enter the column number:";
					cin >> col;
				}

				cout << "Enter the row number:";
				cin >> row_1;
				while (!cin)
				{
					cin.clear();
					cin.ignore(100, '\n');                      //Clear and ignores the bad input
					cout << "Invalid Input.Please Try again\n";
					cout << "Enter the row number:";
					cin >> row_1;
				}

				if (col == 0 && row_1 == 0)
				{
					check_c[0][0] += 1;                    //If a certain value of row and columns meets the condition,
					//then it upgrades the value of lines in boxes 
					//and repetition of that certain value is ignored
					if (!(check_c[0][0] >= 2))
						box1 += 1;
					if (check_c[0][0] >= 2)
					{
						repeat--;
						cout << "You cannot draw line on a same location\n";

					}
				}
				else if (col == 0 && row_1 == 1)
				{
					check_c[1][0] += 1;
					if (!(check_c[1][0] >= 2))
						box4 += 1;
					if (check_c[1][0] >= 2)
					{
						repeat--;
						cout << "You cannot draw line on a same location\n";

					}

				}
				else if (col == 0 && row_1 == 2)
				{
					check_c[2][0] += 1;
					if (!(check_c[2][0] >= 2))
						box7 += 1;
					if (check_c[2][0] >= 2)
					{
						repeat--;
						cout << "You cannot draw line on a same location\n";

					}
				}

				else if (col == 1 && row_1 == 0)
				{
					check_c[0][1] += 1;
					if (!(check_c[0][1] >= 2))
					{
						box1 += 1;
						box2 += 1;
					}
					if (check_c[0][1] >= 2)
					{
						repeat--;
						cout << "You cannot draw line on a same location\n";

					}
				}
				else if (col == 1 && row_1 == 1)
				{
					check_c[1][1] += 1;
					if (!(check_c[1][1] >= 2))
					{
						box4 += 1;
						box5 += 1;
					}
					if (check_c[1][1] >= 2)
					{
						repeat--;
						cout << "You cannot draw line on a same location\n";

					}
				}
				else if (col == 1 && row_1 == 2)
				{
					check_c[2][1] += 1;
					if (!(check_c[2][1] >= 2))
					{
						box7 += 1;
						box8 += 1;
					}
					if (check_c[2][1] >= 2)
					{
						repeat--;
						cout << "You cannot draw line on a same location\n";

					}
				}

				else if (col == 2 && row_1 == 0)
				{
					check_c[0][2] += 1;
					if (!(check_c[0][2] >= 2))
					{
						box2 += 1;
						box3 += 1;
					}
					if (check_c[0][2] >= 2)
					{
						repeat--;
						cout << "You cannot draw line on a same location\n";

					}
				}
				else if (col == 2 && row_1 == 1)
				{
					check_c[1][2] += 1;
					if (!(check_c[1][2] >= 2))
					{
						box5 += 1;
						box6 += 1;
					}
					if (check_c[1][2] >= 2)
					{
						repeat--;
						cout << "You cannot draw line on a same location\n";

					}
				}
				else if (col == 2 && row_1 == 2)
				{
					check_c[2][2] += 1;
					if (!(check_c[2][2] >= 2))
					{
						box8 += 1;
						box9 += 1;
					}
					if (check_c[2][2] >= 2)
					{
						repeat--;
						cout << "You cannot draw line on a same location\n";

					}
				}
				else if (col == 3 && row_1 == 0)
				{
					check_c[0][3] += 1;
					if (!(check_c[0][3] >= 2))
						box3 += 1;
					if (check_c[0][3] >= 2)
					{
						repeat--;
						cout << "You cannot draw line on a same location\n";

					}
				}
				else if (col == 3 && row_1 == 1)
				{
					check_c[1][3] += 1;
					if (!(check_c[1][3] >= 2))
						box6 += 1;
					if (check_c[1][3] >= 2)
					{
						repeat--;
						cout << "You cannot draw line on a same location\n";

					}
				}
				else if (col == 3 && row_1 == 2)
				{
					check_c[2][3] += 1;
					if (!(check_c[2][3] >= 2))
						box9 += 1;
					if (check_c[2][3] >= 2)
					{
						repeat--;
						cout << "You cannot draw line on a same location\n";

					}
				}
				system("pause");
				if ((repeat % 2 == 0 || repeat % 2 == 1) && box1 == 4)
				{                                                          //Upgrading Score values  And  Assigns the Symbols in Boxes.
					if (repeat % 2 == 0)
					{
						arr3[0][0] = "   " + player_1_symbol + "   ";
						player_1_Score = player_1_Score + 1;
					}
					else if (repeat % 2 == 1)
					{
						arr3[0][0] = "   " + player_2_symbol + "   ";
						player_2_Score = player_2_Score + 1;
					}
				}
				if ((repeat % 2 == 0 || repeat % 2 == 1) && box2 == 4)
				{
					if (repeat % 2 == 0)
					{
						arr3[0][1] = "   " + player_1_symbol + "   ";
						player_1_Score = player_1_Score + 1;
					}
					else if (repeat % 2 == 1)
					{
						arr3[0][1] = "   " + player_2_symbol + "   ";
						player_2_Score = player_2_Score + 1;
					}
				}
				if ((repeat % 2 == 0 || repeat % 2 == 1) && box3 == 4)
				{
					if (repeat % 2 == 0)
					{
						arr3[0][2] = "   " + player_1_symbol + "   ";
						player_1_Score = player_1_Score + 1;
					}
					else if (repeat % 2 == 1)
					{
						arr3[0][2] = "   " + player_2_symbol + "   ";
						player_2_Score = player_2_Score + 1;
					}
				}
				if ((repeat % 2 == 0 || repeat % 2 == 1) && box4 == 4)
				{
					if (repeat % 2 == 0)
					{
						arr3[1][0] = "   " + player_1_symbol + "   ";
						player_1_Score = player_1_Score + 1;
					}
					else if (repeat % 2 == 1)
					{
						arr3[1][0] = "   " + player_2_symbol + "   ";
						player_2_Score = player_2_Score + 1;
					}

				}
				if ((repeat % 2 == 0 || repeat % 2 == 1) && box5 == 4)
				{
					if (repeat % 2 == 0)
					{
						arr3[1][1] = "   " + player_1_symbol + "   ";
						player_1_Score = player_1_Score + 1;
					}
					else if (repeat % 2 == 1)
					{
						arr3[1][1] = "   " + player_2_symbol + "   ";
						player_2_Score = player_2_Score + 1;
					}
				}
				if ((repeat % 2 == 0 || repeat % 2 == 1) && box6 == 4)
				{
					if (repeat % 2 == 0)
					{
						arr3[1][2] = "   " + player_1_symbol + "   ";
						player_1_Score = player_1_Score + 1;
					}
					else if (repeat % 2 == 1)
					{
						arr3[1][2] = "   " + player_2_symbol + "   ";
						player_2_Score = player_2_Score + 1;
					}
				}
				if ((repeat % 2 == 0 || repeat % 2 == 1) && box7 == 4)
				{
					if (repeat % 2 == 0)
					{
						arr3[2][0] = "   " + player_1_symbol + "   ";
						player_1_Score = player_1_Score + 1;
					}
					else if (repeat % 2 == 1)
					{
						arr3[2][0] = "   " + player_2_symbol + "   ";
						player_2_Score = player_2_Score + 1;
					}
				}
				if ((repeat % 2 == 0 || repeat % 2 == 1) && box8 == 4)
				{
					if (repeat % 2 == 0)
					{
						arr3[2][1] = "   " + player_1_symbol + "   ";
						player_1_Score = player_1_Score + 1;
					}
					else if (repeat % 2 == 1)
					{
						arr3[2][1] = "   " + player_2_symbol + "   ";
						player_2_Score = player_2_Score + 1;
					}
				}
				if ((repeat % 2 == 0 || repeat % 2 == 1) && box9 == 4)
				{
					if (repeat % 2 == 0)
					{
						arr3[2][2] = "   " + player_1_symbol + "   ";
						player_1_Score = player_1_Score + 1;
					}
					else if (repeat % 2 == 1)
					{
						arr3[2][2] = "   " + player_2_symbol + "   ";
						player_2_Score = player_2_Score + 1;
					}
				}
				if (box1 == 4)                                 //Extra Turn After completing the Boxes.
				{
					repeat += 2;
					box1 = 0;

				}
				if (box2 == 4)
				{
					repeat += 2;
					box2 = 0;
				}
				if (box3 == 4)
				{
					repeat += 2;
					box3 = 0;
				}
				if (box4 == 4)
				{
					repeat += 2;
					box4 = 0;
				}
				if (box5 == 4)
				{
					repeat += 2;
					box5 = 0;
				}
				if (box6 == 4)
				{
					repeat += 2;
					box6 = 0;
				}
				if (box7 == 4)
				{
					repeat += 2;
					box7 = 0;
				}
				if (box8 == 4)
				{
					repeat += 2;
					box8 = 0;
				}
				if (box9 == 4)
				{
					repeat += 2;
					box9 = 0;
				}
				if (row_1 >= 3)                                 //Control the Out of Range Values.
				{
					row_1 = 4;
					repeat--;
					cout << "Out of range.Please Try Again\n";
					system("pause");
				}
				if (col > 3)
				{
					repeat--;
					cout << "Out of range.Please Try Again\n";
					system("pause");
				}
				for (int col_out = 0; col_out < 4; col_out++)         //Array is used for Vertical Lines in Boxes.
				{
					for (int row_out = 0; row_out < 3; row_out++)
					{

						if (col == 0 && row_1 == 0 || col == 0 && row_1 == 1 || col == 0 && row_1 == 2)
						{
							arr2[row_1][col] = "\t\t\t\t\t|";
						}

						else if (col_out == col && row_out == row_1)
						{
							arr2[row_out][col_out] = "|";
						}

					}
				}
			}

			system("cls");
			for (int row_out = 0; row_out < 4; row_out++)
			{
				for (int col_out = 0; col_out < 4; col_out++)          //Displaying all Stored Values of Horizontal And Vertical Lines. 
				{
					cout << arr1[row_out][col_out] << "\t";
				}
				cout << endl;

				if (row_out < 3)
				{
					for (int col1 = 0; col1 < 4; col1++)
					{
						cout << arr2[row_out][col1];

						for (int col2 = col1; col2 <= col1; col2++)
						{
							cout << arr3[row_out][col2];
						}
					}
				}

				cout << endl;
			}
		}
		else
		{
			cout << "Invalid character input.\nPlease enter 'r' or 'c'.\n";
			repeat--;
		}
		if (player_1_Score + player_2_Score >= 9)
		{
			break;
		}
		if (player_1_Score + player_2_Score == Total_Score)
		{
			repeat++;
		}
	}   //while loop ends here                                          
	if (player_1_Score > player_2_Score)   //Comparison of player_1_Score and player_2_Score 
		//And the decision of winning
	{
		cout << "                               -----------------------------------------\n";
		cout << "                                              CONGRATULAIONS                 \n";
		cout << "                               -----------------------------------------\n";
		cout << "\t\t\t\t\t\t" << player_1_name << " Wins the Game\n";
		cout << "\t\t\t\t\t\t" << player_1_name << " score=" << player_1_Score << endl;
		cout << "\t\t\t\t\t\t" << player_2_name << " score=" << player_2_Score << endl;
	}
	else
	{
		cout << "                               -----------------------------------------\n";
		cout << "                                              CONGRATULAIONS                 \n";
		cout << "                               -----------------------------------------\n";
		cout << "\t\t\t\t\t\t" << player_2_name << " Wins the game\n";
		cout << "\t\t\t\t\t\t" << player_1_name << " score=" << player_1_Score << endl;
		cout << "\t\t\t\t\t\t" << player_2_name << " score=" << player_2_Score << endl;
	}
	system("pause > 0");
	return 0;
}
